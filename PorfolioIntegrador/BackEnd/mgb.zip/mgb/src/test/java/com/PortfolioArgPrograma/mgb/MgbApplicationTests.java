package com.PortfolioArgPrograma.mgb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MgbApplicationTests {

	@Test
	void contextLoads() {
	}

}
