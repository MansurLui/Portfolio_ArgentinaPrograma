package com.botones.botones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotonesApplicationTests {

	@Test
	void contextLoads() {
	}

}
