package com.botones.botones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BotonesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BotonesApplication.class, args);
	}

}
